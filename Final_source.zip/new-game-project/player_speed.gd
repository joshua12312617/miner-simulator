extends Button
@onready var progressbar = $"../UpgradeBar"
@onready var player_speed_label = $"../Label"
@onready var button = $"."
@onready var price_label = $"../Label2"

func _ready() -> void:
	price_label.text = str(WarehouseManager.cost_ps)
func _on_pressed() -> void:
	if WarehouseManager.coin_count >= WarehouseManager.cost_ps and progressbar.value < progressbar.max_value:
		WarehouseManager.coin_count -= WarehouseManager.cost_ps
		WarehouseManager.speed += 20
		progressbar.value += 1
		WarehouseManager.cost_ps *= 2
		
		button.release_focus()
		if progressbar.value < progressbar.max_value:
			price_label.text = str(WarehouseManager.cost_ps)
			player_speed_label.text = str(int(progressbar.value)) + "/" + str(int(progressbar.max_value))
		else:
			price_label.text = "Max"
			player_speed_label.text = "Max Level"
		
	else:
		button.release_focus()
		print("max level")
		
