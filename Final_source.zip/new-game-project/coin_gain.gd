extends Button

@onready var copper = load("res://inventory/copperoreicon.tres")
@onready var silver = load("res://inventory/silveroreicon.tres")
@onready var gold = load("res://assets/Items/goldoreicon.tres")
@onready var purple = load("res://assets/Furniture/purpleoreicon.tres")
@onready var progressbar = $"../UpgradeBar"
@onready var coin_gain_label = $"../Label"
@onready var button = $"."
@onready var price_label = $"../Label2"

func _ready() -> void:
	price_label.text = str(WarehouseManager.cost_cg)
	
func _on_pressed() -> void:
	if WarehouseManager.coin_count >= WarehouseManager.cost_cg and progressbar.value < progressbar.max_value:
		copper.coin = copper.coin + 1 * (progressbar.value +1) 
		silver.coin = silver.coin + 2 * (progressbar.value + 2)
		gold.coin = gold.coin + 3 * (progressbar.value + 3)
		purple.coin = purple.coin + 6 * (progressbar.value + 6)
		progressbar.value += 1
		WarehouseManager.coin_count -= WarehouseManager.cost_cg
		WarehouseManager.cost_cg *= 2
		button.release_focus()
		if progressbar.value < progressbar.max_value:
			price_label.text = str(WarehouseManager.cost_cg)
			coin_gain_label.text = str(int(progressbar.value)) + "/" + str(int(progressbar.max_value))
		else:
			price_label.text = "Max"
			coin_gain_label.text = "Max Level"
	else:
		button.release_focus()
		print("max level")
