extends Button

@onready var progressbar = $"../UpgradeBar"
@onready var ore_drop_chance_label = $"../Label"
@onready var button = $"."
@onready var price_label = $"../Label2"
func _ready() -> void:
	price_label.text = str(WarehouseManager.cost_odc)
func _on_pressed() -> void:
	if WarehouseManager.coin_count >= WarehouseManager.cost_odc and progressbar.value < progressbar.max_value:
		WarehouseManager.gold_chance *= 1 + 2 * (progressbar.value / 10)
		WarehouseManager.copper_chance *= 1 + 2 * (progressbar.value / 10)
		WarehouseManager.silver_chance *= 1 + 2 * (progressbar.value / 10)
		WarehouseManager.purple_chance *= 1 + 2 * (progressbar.value / 10)
		progressbar.value += 1
		WarehouseManager.coin_count -= WarehouseManager.cost_odc
		WarehouseManager.cost_odc *= 2
		button.release_focus()
		if progressbar.value < progressbar.max_value:
			price_label.text = str(WarehouseManager.cost_odc)
			ore_drop_chance_label.text = str(int(progressbar.value)) + "/" + str(int(progressbar.max_value))
		else:
			price_label.text = "Max"
			ore_drop_chance_label.text = "Max Level"
	else:
		button.release_focus()
		print("max level")
