extends Button


var is_open = false 


func _ready():
	close()
	
func _process(delta):
	pass
		

func open():
	visible = true
	is_open = true
func close():
	visible = false
	is_open = false



func _on_button_down() -> void:
	open() # Replace with function bodys

func _on_button_up() -> void:
	close()
	
			
func _input(event):
	if event is InputEventKey and event.keycode == KEY_TAB:
		if event.pressed and not event.echo:
			_on_button_down()
		elif not event.pressed and not event.echo:
			_on_button_up()
