extends Node

@onready var warehouse_inv: Inv = preload("res://assets/warehouse_inv.tres")

var coin_count = 100000000
var is_processing = false
var speed = 100 #player.gd
var cost_ps = 5 #player_speed_gd.gd 
var cost_odc = 35 #ore_drop_chance_upg.gd
var cost_op =  25 #ore_process_upg.gd
var cost_cg = 15 #coin_gains_upg.gd
var gold_chance = 0.01 #drop chance||stone.gd
var copper_chance = 0.1 #drop chance||stone.gd
var silver_chance = 0.05 #drop chance||stone.gd
var purple_chance = 0.005 #drop chance||stone.gd
var processing_label: Label = null

func display_message(msg: String):
	print(msg)
	if processing_label:
		processing_label.text = msg

func set_processing_label(label: Label):
	processing_label = label

func _ready():
	print("Warehouse manager ready.")



	#sort ore by priority
func sorted_items_by_priority(slots: Array) -> Array:
	var priority_map = {
		"legend": 4,
		"epic": 3,
		"rare": 2,
		"common": 1
	}
	var valid_slots = slots.filter(func(slot):
		return slot.item != null and slot.amount > 0
	)
	for i in range(valid_slots.size()):
		for j in range(i + 1, valid_slots.size()):
			var a_priority = priority_map.get(valid_slots[i].item.Prio, 0)
			var b_priority = priority_map.get(valid_slots[j].item.Prio, 0)
			if b_priority > a_priority:
				var temp = valid_slots[i]
				valid_slots[i] = valid_slots[j]
				valid_slots[j] = temp
	return valid_slots


# NPPS
func ALGO2():
	if is_processing:
		return 
	is_processing = true
	while true:
		var sorted_slots = sorted_items_by_priority(warehouse_inv.slots)

		if sorted_slots.is_empty():
			break 
		display_message("Furnace starting.")
		await get_tree().create_timer(2).timeout 
		await process_items(sorted_slots)
	await get_tree().create_timer(0.2).timeout 
	is_processing = false
	print("Furnace done. Waiting for new items...")
	
# FCFS
func ALGO1():
	if is_processing:
		return 
	is_processing = true
	
	while true:
		var valid_slots = warehouse_inv.slots.filter(func(slot):
			return slot.item != null and slot.amount > 0
		)
		if valid_slots.is_empty():
			break  
		display_message("Furnace starting.")
		await get_tree().create_timer(2).timeout
		await process_items(valid_slots)
	await get_tree().create_timer(0.2).timeout
	is_processing = false
	print("Furnace done. Waiting for new items...")
	
	
	
	
	
#Process items one by one with the data item returned
func process_items(slots: Array) -> void:
	for slot in slots: 
		var item = slot.item
		while slot.amount > 0:
			display_message("Processing:%s [%s](BT: %d sec, Coin: %d)" % [item.name, item.Prio, item.BT, item.coin] + "\nAmount before: %d" % slot.amount)
			
			await get_tree().create_timer(item.BT).timeout
			slot.amount -= 1
			if slot.amount < 1:
				slot.item = null
			add_coins(item.coin)
			display_message("Ore processing is finished" + "\n\nWaiting for new items...")
			print("Furnace done. Total coins earned: ", coin_count)
			

func add_coins(value: int):
	coin_count += value
	#coin_label.text = "Coins: %d" % coin_count
