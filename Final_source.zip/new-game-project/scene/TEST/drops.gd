extends Node2D
@onready var copper = load("res://inventory/copperoreicon.tres")
@onready var silver = load("res://inventory/silveroreicon.tres")
@onready var gold = load("res://assets/Items/goldoreicon.tres")
@onready var amethyst = load("res://assets/Furniture/purpleoreicon.tres")
@onready var copper_label = $copper_label
@onready var silver_label = $silver_label
@onready var gold_label = $gold_label
@onready var amethyst_label = $amethyst_label
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	copper_label.text = copper.name + "[BT:" + str(copper.BT) + "] [Coin:" + str(copper.coin) + "]"
	silver_label.text = silver.name + "[BT:" + str(silver.BT) + "] [Coin:" + str(silver.coin) + "]" 
	gold_label.text = gold.name + "[BT:" + str(gold.BT) + "] [Coin:" + str(gold.coin) + "]"
	amethyst_label.text = amethyst.name + "[BT:" + str(amethyst.BT) + "] [Coin:" + str(amethyst.coin) + "]"
