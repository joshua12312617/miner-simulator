extends Node2D

@onready var bg: AudioStreamPlayer2D = $BG_MUSIC
@onready var current_processing = $Label6
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	bg.play() 
	WarehouseManager.set_processing_label($Label6)
	

func _process(delta: float) -> void:
	pass
