extends TileMapLayer


var original_position: Vector2

func _ready():
	original_position = position

func shake():
	var tween = create_tween()
	tween.set_loops(4)  # Number of shake repetitions
	tween.set_trans(Tween.TRANS_SINE)
	tween.set_ease(Tween.EASE_IN_OUT)

	# Shake right
	tween.tween_property(self, "position", original_position + Vector2(3, 0), 0.05)
	# Shake left
	tween.tween_property(self, "position", original_position - Vector2(3, 0), 0.1)
	# Return to original
	tween.tween_property(self, "position", original_position, 0.05)
