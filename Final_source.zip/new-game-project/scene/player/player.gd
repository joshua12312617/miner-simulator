extends CharacterBody2D
class_name player

var current_direction = "none"

@export var inv: Inv
@onready var walking_sfx: AudioStreamPlayer2D = $AudioStreamPlayer2D
@onready var attack_sfx: AudioStreamPlayer2D = $AudioStreamPlayer2D2

func collect(item):
	inv.insert(item)

func _ready():
	$AnimatedSprite2D.play("idle")

func _physics_process(delta):
	player_movement(delta)
	move_and_slide()

func player_movement(delta):
	var anim = $AnimatedSprite2D
	var moving = false
	velocity = Vector2.ZERO
	
	# Handle horizontal movement
	if Input.is_action_pressed("walk_right"):
		velocity.x += WarehouseManager.speed
		current_direction = "right"
		moving = true
	elif Input.is_action_pressed("walk_left"):
		velocity.x -= WarehouseManager.speed
		current_direction = "left"
		moving = true

	# Handle vertical movement
	if Input.is_action_pressed("walk_down"):
		velocity.y += WarehouseManager.speed
		current_direction = "down"
		moving = true
	elif Input.is_action_pressed("walk_up"):
		velocity.y -= WarehouseManager.speed
		current_direction = "up"
		moving = true

	# Play walking animations if moving
	if moving:
		if not walking_sfx.playing:
			walking_sfx.play()
		match current_direction:
			"right":
				anim.flip_h = false
				anim.play("walking_right")
			"left":
				anim.flip_h = true
				anim.play("walking_left")
			"up":
				anim.play("walking_up")
			"down":
				anim.play("walking_down")
	else:
		# Play idle animations when not moving
		match current_direction:
			"right":
				anim.flip_h = false
				anim.play("idle_right")
			"left":
				anim.flip_h = true
				anim.play("idle_left")
			"up":
				anim.play("idle_up")
			"down", _:
				anim.play("idle")


	if Input.is_action_just_pressed("attack"):
		anim.play("attack")
		attack_sfx.play()
