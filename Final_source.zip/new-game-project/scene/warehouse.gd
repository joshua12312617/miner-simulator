extends Area2D

@export var warehouse_inv: Inv  # Assign the warehouse inventory resource in the Inspector
@onready var furnace_sfx: AudioStreamPlayer2D = $AudioStreamPlayer2D
var was_processing = false

func _ready() -> void:
	print("Processing status:", WarehouseManager.is_processing)
	
func _process(delta):
	_music()
	#when player or cart enter the furnace area decide to pass if player or cart has item in storage,
	#if there is nothing to pass then nothing happens  
	#another thing is if the furnace is processing ore player or cart wont be able to pass his items to furnace inventory 
func _on_body_entered(body: Node2D) -> void:
	var player_inv: Inv = body.inv
	if WarehouseManager.is_processing:
		print("Furnace is processing. Cannot add items now.")
	elif player_has_items(player_inv):
		move_inventory(player_inv, warehouse_inv)
		print("Inventory moved to warehouse!")
	else:
		print("Player inventory is empty, nothing to move.")
	
		
#source player
#target warehouse
func move_inventory(source: Inv, target: Inv):
	for source_slot in source.slots:
		if source_slot.item != null and source_slot.amount > 0:
			var item = source_slot.item #player item 
			var amount = source_slot.amount
			# Check if the item already exists in the target
			var matching_slot = target.slots.filter(func(slot): return slot.item == item)

			if !matching_slot.is_empty():
				# Add to existing stack of item
				matching_slot[0].amount += amount
			else:
				# Place item in empty slot
				var empty_slots = target.slots.filter(func(slot): return slot.item == null)
				if !empty_slots.is_empty():
					empty_slots[0].item = item
					empty_slots[0].amount = amount
				else:
					print("No space in warehouse for item: ", item.name)

			# Clear source slot
			source_slot.item = null
			source_slot.amount = 0

	# Update if the player inventory
		target.update.emit()
		source.update.emit()
		
	#checks if the player inventory have any items
func player_has_items(inv: Inv) -> bool:
	for slot in inv.slots:
		if slot.item != null and slot.amount > 0:
			return true
	return false
	
func _music():
	if WarehouseManager.is_processing and not was_processing:
		furnace_sfx.play()
	elif not WarehouseManager.is_processing and was_processing:
		furnace_sfx.stop()
	was_processing = WarehouseManager.is_processing

	
	
