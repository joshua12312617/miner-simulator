extends Sprite2D

@onready var coin_label = $Label

func _process(delta: float) -> void:
	coin_label.text = str(WarehouseManager.coin_count)
