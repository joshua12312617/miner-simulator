extends Resource

class_name InvItem


@export var name: String = ""
@export var texture: Texture2D
@export var BT: int = 0
@export var Prio: String = ""
@export var coin: int = 0
