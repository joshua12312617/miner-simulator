extends Button

@onready var copper = load("res://inventory/copperoreicon.tres")
@onready var silver = load("res://inventory/silveroreicon.tres")
@onready var gold = load("res://assets/Items/goldoreicon.tres")
@onready var purple = load("res://assets/Furniture/purpleoreicon.tres")
@onready var progressbar = $"../UpgradeBar"
@onready var ore_process_label = $"../Label"
@onready var button = $"."
@onready var price_label = $"../Label2"

func _ready() -> void:
	price_label.text = str(WarehouseManager.cost_op)
func _on_pressed() -> void:
	if WarehouseManager.coin_count >= WarehouseManager.cost_op and progressbar.value < progressbar.max_value:
		copper.BT = max(1, copper.BT - 1)
		silver.BT = max(1, silver.BT - 1)
		gold.BT = max(1, gold.BT - 1)
		purple.BT = max(1, purple.BT - 1)
		progressbar.value += 1
		WarehouseManager.coin_count -= WarehouseManager.cost_op
		WarehouseManager.cost_op *= 2
		button.release_focus()
		if progressbar.value < progressbar.max_value:
			price_label.text = str(WarehouseManager.cost_op)
			ore_process_label.text = str(int(progressbar.value)) + "/" + str(int(progressbar.max_value))
		else:
			price_label.text = "Max"
			ore_process_label.text = "Max Level"
	else:
		button.release_focus()
		print("max level")
