extends Area2D

@export var item_data: InvItem
@onready var pickup_sfx = $AnimationPlayer

var player = null

func _on_body_entered(body: Node2D) -> void:
	# Add item to inventory
	player = body
	player.collect(item_data)
	print("+1 ", item_data.name)
	print("BT:", item_data.BT, ", Prio:", item_data.Prio, ", Coin:", item_data.coin)
	pickup_sfx.play("pick_up")
