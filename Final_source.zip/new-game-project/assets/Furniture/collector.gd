extends AnimatableBody2D
@onready var animetion = $AnimationPlayer


@export var inv: Inv

func collect(item):
	inv.insert(item)
	

	

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("m"):
		animetion.play("collect")
	if Input.is_action_just_pressed("n"):
		var current_time = animetion.current_animation_position
		animetion.stop()
		animetion.seek(current_time, true)
	


func _on_ready() -> void:
	animetion.stop()
