extends Control


@onready var warehouse_inv:Inv = preload("res://assets/warehouse_inv.tres")
@onready var slots: Array = $NinePatchRect/GridContainer.get_children()
@onready var sfx: AudioStreamPlayer2D = $"../AudioStreamPlayer2D"

var coin_count = 0
var iss_open = false



	
func _ready():
	warehouse_inv.update.connect(update_slots)
	update_slots()
	close()


	
	#updating visual slots for warehouse/furnace inventory
func update_slots():
	for i in range(min(warehouse_inv.slots.size(), slots.size())):
		slots[i].update(warehouse_inv.slots[i])
		
	#game keys for warehouse/furnace inventory 
func _process(delta):
	if Input.is_action_just_pressed("o"):
		if iss_open:
			close()
		else:
			open()
	if Input.is_action_just_pressed("1"):
		WarehouseManager.ALGO1()
	if Input.is_action_just_pressed("2"):
		WarehouseManager.ALGO2()
	update_slots()
	
func open():
	visible = true
	iss_open = true
func close():
	visible = false
	iss_open = false
	
	
	
	


	
	
	
	
	
	
	
	
	
	
